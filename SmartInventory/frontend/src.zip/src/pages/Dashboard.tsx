import { Grid, Typography } from "@mui/material";
import { useEffect, useState } from "react";

import DashboardLayout from "../layouts/DashboardLayout";

import KPICard from "../components/dashboard/KPICard";
import SalesChart from "../components/dashboard/SalesChart";
import CategoryChart from "../components/dashboard/CategoryChart";
import InventoryHealthChart from "../components/dashboard/InventoryHealthChart";
import Inventory2Icon from "@mui/icons-material/Inventory2";
import StoreIcon from "@mui/icons-material/Store";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import MonitorHeartIcon from "@mui/icons-material/MonitorHeart";

import{
    getDashboardSummary,
    type DashboardSummary,
} from "../services/dashboardService";

import{
    getSalesTrend,
    type SalesTrend,
} from "../services/chartService";

import{
    getCategoryDistribution,
    getInventoryHealth,
    type CategoryDistribution,
    type InventoryHealth,
} from "../services/dashboardAnalyticsService";

export default function Dashboard() {

    const [summary, setSummary] =
        useState<DashboardSummary>();

    const [salesTrend, setSalesTrend] =
        useState<SalesTrend[]>([]);

    const [categoryData, setCategoryData] =
        useState<CategoryDistribution[]>([]);

    const [inventoryHealth, setInventoryHealth] =
        useState<InventoryHealth[]>([]);

    useEffect(() => {

        async function loadDashboard() {

            try {

                const [
                    summaryData,
                    salesData,
                    categoryChart,
                    healthChart,
                ] = await Promise.all([

                    getDashboardSummary(),

                    getSalesTrend(),

                    getCategoryDistribution(),

                    getInventoryHealth(),

                ]);

                setSummary(summaryData);

                setSalesTrend(salesData);

                setCategoryData(categoryChart);

                setInventoryHealth(healthChart);

            } catch (error) {

                console.error(error);

            }

        }

        loadDashboard();

    }, []);

    return (

        <DashboardLayout>

            <Typography
                variant="h4"
                gutterBottom
            >
                Dashboard
            </Typography>

            <Grid
                container
                spacing={3}
            >
<Grid size={{ xs:12, md:3 }}>

    <KPICard

        title="Products"

        value={summary?.products ?? 0}

        icon={<Inventory2Icon />}

        color="#2563eb"

        subtitle="Available Products"

    />

</Grid>

<Grid size={{ xs:12, md:3 }}>

    <KPICard

        title="Stores"

        value={summary?.stores ?? 0}

        icon={<StoreIcon />}

        color="#16a34a"

        subtitle="Retail Locations"

    />

</Grid>

<Grid size={{ xs:12, md:3 }}>

    <KPICard

        title="Suppliers"

        value={summary?.suppliers ?? 0}

        icon={<LocalShippingIcon />}

        color="#f59e0b"

        subtitle="Active Suppliers"

    />

</Grid>

<Grid size={{ xs:12, md:3 }}>

    <KPICard

        title="Inventory Health"

        value={`${summary?.inventory_health ?? 0}%`}

        icon={<MonitorHeartIcon />}

        color="#dc2626"

        subtitle="Current Health"

    />

</Grid>
                <Grid size={{ xs: 12 }}>
                    <SalesChart
                        data={salesTrend}
                    />
                </Grid>

                <Grid size={{ xs: 12, md: 6 }}>
                    <CategoryChart
                        data={categoryData}
                    />
                </Grid>

                <Grid size={{ xs: 12, md: 6 }}>
                    <InventoryHealthChart
                        data={inventoryHealth}
                    />
                </Grid>

            </Grid>

        </DashboardLayout>

    );

}