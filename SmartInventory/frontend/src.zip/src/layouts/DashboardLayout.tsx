import { Box, Toolbar } from "@mui/material";
import Sidebar from "../components/layout/Sidebar";
import type Navbar  from "../components/layout/Navbar";

interface Props {
    children: React.ReactNode;
}

export default function DashboardLayout({ children }: Props) {
    return (
        <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "#f8fafc" }}>
            <Sidebar />

            <Box
                component="main"
                sx={{
                    flexGrow: 1,
                    display: "flex",
                    flexDirection: "column",
                    overflow: "hidden",
                }}
            >
                <Navbar />

                <Toolbar />

                <Box
                    sx={{
                        flex: 1,
                        p: {
                            xs: 2,
                            sm: 3,
                            md: 4,
                        },
                        overflowY: "auto",
                    }}
                >
                    {children}
                </Box>
            </Box>
        </Box>
    );
}