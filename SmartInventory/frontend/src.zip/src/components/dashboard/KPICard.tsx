import {
    Card,
    CardContent,
    Typography,
    Box
} from "@mui/material";

import TrendingUpIcon from "@mui/icons-material/TrendingUp";

interface Props {

    title: string;

    value: string | number;

    icon: React.ReactNode;

    color: string;

    subtitle?: string;

}

export default function KPICard({

    title,

    value,

    icon,

    color,

    subtitle,

}: Props) {

    return (

        <Card

            sx={{

                transition: "0.3s",

                cursor: "pointer",

                "&:hover": {

                    transform: "translateY(-6px)",

                    boxShadow: 8,

                },

            }}

        >

            <CardContent>

                <Box

                    display="flex"

                    justifyContent="space-between"

                    alignItems="center"

                >

                    <Typography

                        variant="h6"

                        color="text.secondary"

                    >

                        {title}

                    </Typography>

                    <Box

                        sx={{

                            bgcolor: color,

                            color: "white",

                            p: 1.5,

                            borderRadius: 2,

                        }}

                    >

                        {icon}

                    </Box>

                </Box>

                <Typography

                    variant="h3"

                    sx={{ mt: 3, fontWeight: 700 }}

                >

                    {value}

                </Typography>

                <Box

                    mt={2}

                    display="flex"

                    alignItems="center"

                    gap={1}

                >

                    <TrendingUpIcon

                        fontSize="small"

                        color="success"

                    />

                    <Typography

                        color="text.secondary"

                    >

                        {subtitle ?? "Live Data"}

                    </Typography>

                </Box>

            </CardContent>

        </Card>

    );

}