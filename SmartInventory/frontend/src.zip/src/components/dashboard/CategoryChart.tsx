import {
    PieChart,
    Pie,
    Cell,
    ResponsiveContainer,
    Tooltip,
    Legend
} from "recharts";

import {
    Paper,
    Typography
} from "@mui/material";

const COLORS = [
    "#1976d2",
    "#43a047",
    "#ff9800",
    "#e53935",
    "#8e24aa",
    "#00acc1"
];

interface Props {
    data: any[];
}

export default function CategoryChart({
    data
}: Props) {

    return (

        <Paper
            elevation={4}
            sx={{
                p:2,
                height:350
            }}
        >

            <Typography
                variant="h6"
                gutterBottom
            >
                Category Distribution
            </Typography>

            <ResponsiveContainer>

                <PieChart>

                    <Pie
                        data={data}
                        dataKey="value"
                        nameKey="name"
                        outerRadius={100}
                    >

                        {data.map((_, index) => (

                            <Cell
                                key={index}
                                fill={
                                    COLORS[
                                        index % COLORS.length
                                    ]
                                }
                            />

                        ))}

                    </Pie>

                    <Tooltip />

                    <Legend />

                </PieChart>

            </ResponsiveContainer>

        </Paper>

    );

}