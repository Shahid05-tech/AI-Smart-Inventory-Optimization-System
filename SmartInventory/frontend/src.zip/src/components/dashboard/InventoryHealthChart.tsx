import {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip
} from "recharts";

import {
    Paper,
    Typography
} from "@mui/material";

interface Props{
    data:any[]
}

export default function InventoryHealthChart({
    data
}:Props){

    return(

        <Paper
            elevation={4}
            sx={{
                p:2,
                height:350
            }}
        >

            <Typography
                variant="h6"
                gutterBottom
            >
                Inventory Health
            </Typography>

            <ResponsiveContainer>

                <BarChart
                    data={data}
                >

                    <XAxis
                        dataKey="name"
                    />

                    <YAxis />

                    <Tooltip />

                    <Bar
                        dataKey="count"
                    />

                </BarChart>

            </ResponsiveContainer>

        </Paper>

    )

}