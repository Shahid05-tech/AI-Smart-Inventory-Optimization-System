import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    CartesianGrid
} from "recharts";

import { Paper, Typography } from "@mui/material";

interface Props {
    data: any[];
}

export default function SalesChart({ data }: Props) {

    return (

        <Paper
            elevation={4}
            sx={{
                p: 2,
                mt: 4,
                height: 400
            }}
        >

            <Typography
                variant="h6"
                gutterBottom
            >
                Sales Trend
            </Typography>

            <ResponsiveContainer
                width="100%"
                height="90%"
            >

                <LineChart data={data}>

                    <CartesianGrid strokeDasharray="3 3" />

                    <XAxis dataKey="month" />

                    <YAxis />

                    <Tooltip />

                    <Line
                        type="monotone"
                        dataKey="revenue"
                    />

                </LineChart>

            </ResponsiveContainer>

        </Paper>

    );

}