import {
    Divider,
    Drawer,
    List,
} from "@mui/material";

import DashboardRoundedIcon from "@mui/icons-material/DashboardRounded";
import Inventory2RoundedIcon from "@mui/icons-material/Inventory2Rounded";
import AutoGraphRoundedIcon from "@mui/icons-material/AutoGraphRounded";
import SmartToyRoundedIcon from "@mui/icons-material/SmartToyRounded";

import { NavLink } from "react-router-dom";

import Logo from "./Logo";
import UserProfile from "./UserProfile";

const drawerWidth = 270;

const menus = [

    {
        title: "Dashboard",
        path: "/",
        icon: <DashboardRoundedIcon />,
    },

    {
        title: "Recommendation",
        path: "/recommendation",
        icon: <SmartToyRoundedIcon />,
    },

    {
        title: "Inventory",
        path: "/inventory",
        icon: <Inventory2RoundedIcon />,
    },

    {
        title: "Analytics",
        path: "/analytics",
        icon: <AutoGraphRoundedIcon />,
    },

];

export default function Sidebar() {

    return (

        <Drawer
            variant="permanent"
            sx={{

                width: drawerWidth,

                "& .MuiDrawer-paper": {

                    width: drawerWidth,

                    borderRight: "1px solid #e5e7eb",

                    p: 2,

                },

            }}
        >

            <Logo />

            <Divider sx={{ my: 2 }} />

            <List>

                {

                    menus.map(menu => (

                        <NavLink

                            key={menu.title}

                            to={menu.path}

                            style={({ isActive }) => ({

                                display: "flex",

                                alignItems: "center",

                                gap: 15,

                                padding: 14,

                                borderRadius: 12,

                                marginBottom: 8,

                                color: isActive
                                    ? "#2563EB"
                                    : "#475569",

                                background: isActive
                                    ? "#EFF6FF"
                                    : "transparent",

                                textDecoration: "none",

                                fontWeight: 600,

                            })}

                        >

                            {menu.icon}

                            {menu.title}

                        </NavLink>

                    ))

                }

            </List>

            <UserProfile />

        </Drawer>

    );

}