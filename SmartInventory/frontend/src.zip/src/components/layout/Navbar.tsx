import {
    AppBar,
    Toolbar,
    Typography,
    Box,
    IconButton,
    Avatar,
    Badge,
    TextField,
    InputAdornment,
} from "@mui/material";

import NotificationsNoneRoundedIcon from "@mui/icons-material/NotificationsNoneRounded";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import LightModeRoundedIcon from "@mui/icons-material/LightModeRounded";

export default function Navbar() {

    return (

        <AppBar

            position="fixed"

            elevation={0}

            sx={{

                bgcolor: "white",

                color: "#0f172a",

                borderBottom: "1px solid #e5e7eb",

                ml: "270px",

                width: "calc(100% - 270px)",

            }}

        >

            <Toolbar

                sx={{

                    display: "flex",

                    justifyContent: "space-between",

                }}

            >

                <Box>

                    <Typography

                        variant="h5"

                        fontWeight={700}

                    >

                        Smart Inventory Dashboard

                    </Typography>

                    <Typography

                        variant="body2"

                        color="text.secondary"

                    >

                        AI Powered Inventory Optimization System

                    </Typography>

                </Box>

                <Box

                    display="flex"

                    alignItems="center"

                    gap={2}

                >

                    <TextField

                        placeholder="Search..."

                        size="small"

                        sx={{

                            width: 250,

                        }}

                        InputProps={{

                            startAdornment: (

                                <InputAdornment position="start">

                                    <SearchRoundedIcon />

                                </InputAdornment>

                            ),

                        }}

                    />

                    <IconButton>

                        <LightModeRoundedIcon />

                    </IconButton>

                    <IconButton>

                        <Badge

                            badgeContent={3}

                            color="error"

                        >

                            <NotificationsNoneRoundedIcon />

                        </Badge>

                    </IconButton>

                    <Avatar

                        sx={{

                            bgcolor: "primary.main",

                        }}

                    >

                        A

                    </Avatar>

                </Box>

            </Toolbar>

        </AppBar>

    );

}