import {

Card,

CardContent,

Typography

} from "@mui/material";

interface Props{

title:string;

children:React.ReactNode;

}

export default function ChartCard({

title,

children

}:Props){

return(

<Card

variant="outlined"

sx={{

height:"100%",

borderRadius:4,

boxShadow:"0 8px 20px rgba(15,23,42,.05)"

}}

>

<CardContent>

<Typography

variant="h6"

fontWeight={700}

mb={2}

>

{title}

</Typography>

{children}

</CardContent>

</Card>

)

}