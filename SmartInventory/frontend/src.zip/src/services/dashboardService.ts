import { api } from "../api/api";

export interface DashboardSummary {

    products: number;

    stores: number;

    suppliers: number;

    inventory_health: number;

}

export async function getDashboardSummary() {

    const response =
        await api.get<DashboardSummary>(
            "/dashboard/summary"
        );

    return response.data;

}